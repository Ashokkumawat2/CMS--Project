const router=require('express').Router()
const regc=require('../controllers/regcontrollers')
const multer=require('multer')

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/profileimage')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage: storage,
    limits:{fieldSize:1024*1024*4}
})
function handlogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/')
    }
}
function handlerole(req,res,next){
    if(req.session.role=='subscribe'){
        next()
    }else{
        res.send('you dont subscribe  us to see the details.please subscribe us')
    }
}

router.get('/',regc.loginpage)
router.get('/signup',regc.signuppage)
router.post('/signup',regc.registration)
router.post('/',regc.logincheck)
router.get('/forgotform',regc.forgotform)
router.post('/forgotform',regc.sendlink)
router.get('/forgotchangepasswordform/:email',regc.forgotchangepasswordform)
router.post('/forgotchangepasswordform/:email',regc.changepassword)
router.get('/logout',regc.logout)
router.get('/emailactivelink/:email',regc.activelink)
router.get('/userprofile', handlogin,regc.usersprofile)
router.get('/profileupdate',regc.userupdateform)
router.post('/profileupdate',upload.single('img'),regc.userprofileupdate)
router.get('/singledetail/:id',handlerole,regc.singleprofile)







module.exports=router