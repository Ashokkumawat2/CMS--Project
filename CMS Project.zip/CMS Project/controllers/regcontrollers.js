const Reg=require('../models/reg')
const bcrypt=require('bcrypt')
const nodemailer=require('nodemailer')

exports.loginpage=(req,res)=>{
    res.render('login.ejs',{message:''})
}
exports.signuppage=(req,res)=>{
    res.render('signup.ejs',{message:''})
}
exports.registration= async(req,res)=>{
    const{email,pass}=req.body
    try{
    const convertpass= await bcrypt.hash(pass,10)
   const usercheck=await Reg.findOne({email:email})
   if(usercheck==null){
   const record=new Reg({email:email,password:convertpass})
    record.save()
    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: 'akki27305@gmail.com', // generated ethereal user
        pass:'wlmopyrouyntrksu', // generated ethereal password
      },
    });
    console.log('conneted to gmail smpt server')
    let info = await transporter.sendMail({
      from: 'akki27305@gmail.com', // sender address
      to: email, // list of receivers
      subject: 'Email verification Link-6pm project', // Subject line
      text: "click on below link activate  your account", // plain text body
      html: `<a href=http://localhost:5000/emailactivelink/${email}>click to open Google</a>`, // html body
    });
    console.log('send link to email id')

    //console.log(record)
    res.render('signup.ejs',{message:'Account has been create successfully'})
   }else{
    res.render('signup.ejs',{message:'Email is already Regestered with us'})

   }
}catch(error){
    console.log(error)

}
    
 }
 exports.logincheck= async(req,res)=>{
   const{email,pass}=req.body
   const record=await Reg.findOne({email:email})
   if(record!==null){
   const passwordcheck=await bcrypt.compare(pass,record.password)
   if(passwordcheck){
    req.session.isAuth=true
    req.session.loginname=email
    req.session.role=record.role
    if(record.email=='admin@gmail.com'|| record.email=='admin1@gmail.com'){
        res.redirect('/admin/dashboard')
        }else if(record.status=='unverified'){
          res.render('login.ejs',{message:'Your Email is not verified.please check your email to verified it '})

        }else{
          res.redirect('/userprofile')
        }
   }else{
        res.render('login.ejs',{message:'worng crdentails'})

   }

   }else{
    res.render('login.ejs',{message:'worng crdentails'})
   }

 }
 exports.forgotform=(req,res)=>{
    res.render('forgotform.ejs',{message:''})
 }
 exports.sendlink= async(req,res)=>{
    const{email}=req.body
    const record=await Reg.findOne({email:email})
    if(record==null){
        res.render('forgotform.ejs',{message:'Email not registered with us'})
    }else{
        let testAccount = await nodemailer.createTestAccount();

        // create reusable transporter object using the default SMTP transport
        let transporter = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 587,
          secure: false, // true for 465, false for other ports
          auth: {
            user: 'akki27305@gmail.com', // generated ethereal user
            pass:'wlmopyrouyntrksu', // generated ethereal password
          },
        });
        console.log('conneted to gmail smpt server')
        let info = await transporter.sendMail({
            from: 'akki27305@gmail.com', // sender address
            to: email, // list of receivers
            subject: 'forgot password Link-6pm project', // Subject line
            text: "click on below click to change your password", // plain text body
            html: `<a href=http://localhost:5000/forgotchangepasswordform/${email}>click to open Google</a>`, // html body
          });
          console.log('send link to email id')
          res.render('forgotform.ejs',{message:'Link has been send.please check your email'})
      
    }

 }
 exports.forgotchangepasswordform=(req,res)=>{
const email =req.params.email
    res.render('forgotpasswordchangeform.ejs',{email})
 }
 exports.changepassword= async(req,res)=>{
  const email= req.params.email
 const record= await Reg.findOne({email:email})
 const id= record.id
   const{password}=req.body
   const newpass=await bcrypt.hash(password,10)
   await Reg.findByIdAndUpdate(id,{password:newpass})
   res.render('forgotpasswordmessage.ejs')
 }
 exports.admindashboard=(req,res)=>{
const loginname=req.session.loginname
  res.render('admin/dashboard.ejs',{loginname})
 }
 exports.logout=(req,res)=>{
  req.session.destroy()
  res.redirect('/')
 }
 exports.allusers= async(req,res)=>{
  const loginname=req.session.loginname
  const record=await Reg.find()
  //console.log(record)

  res.render('admin/users.ejs',{loginname,record})
 }
 exports.userdelete= async(req,res)=>{
 const id=req.params.id
 const record=await Reg.findByIdAndDelete(id)
 //console.log(record)
 res.redirect('/admin/users')
 }
 exports.activelink= async(req,res)=>{
 const email=req.params.email
 const record=await Reg.findOne({email:email})
 const id=record.id
 await Reg.findByIdAndUpdate(id,{status:'verified'})
 res.render('activelinkmessage.ejs',{message:'!!!Your Account has been active'})
 }
 exports.usersprofile=async(req,res)=>{
  const loginname=req.session.loginname
  const record=await Reg.find({img:{$nin:['defaultimg.png']}})

  res.render('usersprofile.ejs',{loginname,record})
 }
 exports.userupdateform=async(req,res)=>{
  const loginname=req.session.loginname
  const record=await Reg.findOne({email:loginname})
  //console.log(record)

  res.render('profileupdateform.ejs',{loginname,record,message:''})
 }
 exports.userprofileupdate=async(req,res)=>{
 const{fname,lname,mobile,about}=req.body
 const loginname=req.session.loginname
 const record=await Reg.findOne({email:loginname})
 const id=record.id
 if(req.file){
  const filename=req.file.filename
 await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile,desc:about,img:filename})
 }else{
  await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile,desc:about})

 }
 //res.render('profileupdateform.ejs',{loginname,record,message:'successfully has been updated'})
 res.redirect('/profileupdate')

 }
 exports.singleprofile=async(req,res)=>{
   const id=req.params.id
   const loginname=req.session.loginname
   const record=await Reg.findById(id)
   res.render('singleprofile.ejs',{loginname,record})
 }
 exports.roleupdate=async(req,res)=>{
 const id=req.params.id
 const record=await Reg.findById(id)
 let currentrole=null
 if(record.role=='subscribe'){
  currentrole='public'
 }else{
  currentrole='subscribe'
 }
 await Reg.findByIdAndUpdate(id,{role:currentrole})
 res.redirect('/admin/users')

 }
